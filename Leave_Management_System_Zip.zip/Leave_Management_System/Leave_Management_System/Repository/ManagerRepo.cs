﻿using Leave_Management_System.DataBase;
using Leave_Management_System.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Leave_Management_System.Repository
{
    public class ManagerRepo : IManagerRepo
    {
        private readonly LMSConnect lMSConnect;

        public ManagerRepo(LMSConnect lMSConnect)
        {
            this.lMSConnect = lMSConnect;
        }
        public async Task<List<Manager>> GetAllManager()
        {
            var ar = await lMSConnect.Managers.ToListAsync();
            return ar;
        }

        public async Task<Manager> GetManagerById(int id)
        {
            var ar = await lMSConnect.Managers.Where(x => x.ManagerId == id).FirstOrDefaultAsync();
            return ar;
        }

        public async Task<int> AddManager(Manager manager)
        {
            lMSConnect.Managers.Add(new Manager { ManagerPassword = manager.ManagerPassword, FullName = manager.FullName, ManagerEmailId = manager.ManagerEmailId, ManagerMobileNo = manager.ManagerMobileNo });
            await lMSConnect.SaveChangesAsync();
            return manager.ManagerId;
        }

        public async Task<int> DeleteManager(int id)
        {
            var ar = await lMSConnect.Managers.Where(x => x.ManagerId == id).FirstOrDefaultAsync();
            if (ar != null)
            {
                lMSConnect.Managers.Remove(ar);
                await lMSConnect.SaveChangesAsync();
            }
            return id;
        }

        public async Task<int> UpdateManager(int id, Manager manager)
        {
            var ar = await lMSConnect.Managers.Where(x => x.ManagerId == id).FirstOrDefaultAsync();
            if (ar != null)
            {
                ar.ManagerPassword = manager.ManagerPassword;
                ar.FullName = manager.FullName;
                ar.ManagerEmailId = manager.ManagerEmailId;
                ar.ManagerMobileNo = manager.ManagerMobileNo;
                await lMSConnect.SaveChangesAsync();
            }
            return id;
        }

        public async Task<Manager> Login(int id, string Password)
        {
            var ar = await lMSConnect.Managers.Where(x => x.ManagerId == id && x.ManagerPassword == Password).FirstOrDefaultAsync();
            return ar;
        }
    }
}

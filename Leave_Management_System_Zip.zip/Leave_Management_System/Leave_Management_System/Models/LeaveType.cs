﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Leave_Management_System.Models
{
    public class LeaveType
    {
        [Key]
        public int id { get; set; }
        
        [Required]
        [ForeignKey("leaveid")]
        public int leaveid { get; set; }

        

        [Required]
        public string leaveType { get; set; }
    }
}
